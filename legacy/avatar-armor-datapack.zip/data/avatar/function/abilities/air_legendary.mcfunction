function avatar:abilities/air_sovereign
