function avatar:abilities/fire_sovereign
