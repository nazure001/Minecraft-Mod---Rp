function avatar_skills:give/all_skills
