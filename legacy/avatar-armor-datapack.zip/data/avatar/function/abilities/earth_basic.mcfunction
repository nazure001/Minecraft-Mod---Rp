function avatar:abilities/earth_initiate
