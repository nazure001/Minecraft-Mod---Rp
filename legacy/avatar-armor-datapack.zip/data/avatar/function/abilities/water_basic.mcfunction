function avatar:abilities/water_initiate
