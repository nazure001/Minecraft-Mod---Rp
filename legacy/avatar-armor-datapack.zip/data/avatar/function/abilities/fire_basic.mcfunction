function avatar:abilities/fire_initiate
