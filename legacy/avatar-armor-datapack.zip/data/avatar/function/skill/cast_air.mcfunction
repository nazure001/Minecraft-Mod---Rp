# Avatar Armor Skill Cast - Air
scoreboard players set @s avatar_skill 4
scoreboard players set @s avatar_skill_timer 80
particle minecraft:small_gust ~ ~1 ~ 0.5 0.5 0.5 0.05 15 normal
title @s actionbar [{"text":"[SKILL] ","color":"gold","bold":true},{"text":"Air Skill Activated (80 ticks)","color":"gold"}]
playsound minecraft:entity.illusioner.cast_spell player @s ~ ~ ~ 0.7 1.2
