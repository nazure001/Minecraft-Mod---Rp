function avatar:abilities/earth_sovereign
