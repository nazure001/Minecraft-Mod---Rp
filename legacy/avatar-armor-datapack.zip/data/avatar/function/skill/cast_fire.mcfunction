# Avatar Armor Skill Cast - Fire
scoreboard players set @s avatar_skill 1
scoreboard players set @s avatar_skill_timer 80
particle minecraft:flame ~ ~1 ~ 0.5 0.5 0.5 0.05 15 normal
title @s actionbar [{"text":"[SKILL] ","color":"gold","bold":true},{"text":"Fire Skill Activated (80 ticks)","color":"red"}]
playsound minecraft:entity.illusioner.cast_spell player @s ~ ~ ~ 0.7 1.2
