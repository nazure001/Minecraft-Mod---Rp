function avatar:abilities/water_sovereign
