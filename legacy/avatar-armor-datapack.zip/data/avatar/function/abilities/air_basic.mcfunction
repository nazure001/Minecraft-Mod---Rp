function avatar:abilities/air_initiate
