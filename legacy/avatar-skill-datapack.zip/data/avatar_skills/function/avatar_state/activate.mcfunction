# Activate Avatar State
scoreboard players set @s avatar_state 600
playsound minecraft:ui.toast.challenge_complete player @a ~ ~ ~ 1.5 1.0
playsound minecraft:entity.wither.spawn player @a ~ ~ ~ 0.8 1.8

effect give @s minecraft:resistance 30 2 true
effect give @s minecraft:speed 30 2 true
effect give @s minecraft:strength 30 2 true
effect give @s minecraft:regeneration 30 1 true
effect give @s minecraft:night_vision 30 0 true
effect give @s minecraft:glowing 30 0 true

title @s title {"text":"🌀 AVATAR STATE AWAKENED 🌀","color":"light_purple","bold":true}
title @s subtitle {"text":"Raava's Cosmic Power Channels Through You!","color":"gold"}
