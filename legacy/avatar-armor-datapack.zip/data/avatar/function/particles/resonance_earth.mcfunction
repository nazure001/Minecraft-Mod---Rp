# Elemental Resonance: Pure Earth Overdrive (Earth Armor + Earth Skill)
execute if score @s avatar_set matches 31..32 run particle minecraft:spore_blossom_air ~ ~0.4 ~ 0.3 0.2 0.3 0.02 6 normal
execute if score @s avatar_set matches 33..34 run particle minecraft:dust 0.1 0.8 0.4 1.2 ~ ~0.7 ~ 0.4 0.4 0.4 0.02 8 normal
execute if score @s avatar_set matches 35..36 run particle minecraft:dust 0.1 0.95 0.5 1.8 ~ ~0.9 ~ 0.5 0.6 0.5 0.03 12 normal
execute if score @s avatar_set matches 37 run particle minecraft:dust 0.1 0.95 0.5 1.8 ~ ~1.0 ~ 0.6 0.8 0.6 0.04 18 normal
execute if score @s avatar_set matches 37 run particle minecraft:dust 0.1 0.95 0.5 2.0 ~ ~1.1 ~ 0.5 0.6 0.5 0.03 14 normal
execute if score @s avatar_set matches 37 run particle minecraft:falling_obsidian_tear ~ ~1.3 ~ 0.3 0.3 0.3 0.02 6 normal
