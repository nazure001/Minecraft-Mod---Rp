# Avatar Armor Skill Cast - Earth
scoreboard players set @s avatar_skill 3
scoreboard players set @s avatar_skill_timer 80
particle minecraft:spore_blossom_air ~ ~1 ~ 0.5 0.5 0.5 0.05 15 normal
title @s actionbar [{"text":"[SKILL] ","color":"gold","bold":true},{"text":"Earth Skill Activated (80 ticks)","color":"green"}]
playsound minecraft:entity.illusioner.cast_spell player @s ~ ~ ~ 0.7 1.2
