# Avatar Armor Skill Cast - Water
scoreboard players set @s avatar_skill 2
scoreboard players set @s avatar_skill_timer 80
particle minecraft:splash ~ ~1 ~ 0.5 0.5 0.5 0.05 15 normal
title @s actionbar [{"text":"[SKILL] ","color":"gold","bold":true},{"text":"Water Skill Activated (80 ticks)","color":"aqua"}]
playsound minecraft:entity.illusioner.cast_spell player @s ~ ~ ~ 0.7 1.2
